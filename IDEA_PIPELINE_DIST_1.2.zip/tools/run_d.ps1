﻿param(
  [string]$IdeaDir = "",
  [switch]$All
)

# --- Encoding / Unicode safety ---
$OutputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
try { chcp 65001 | Out-Null } catch {}
# ---------------------------------

$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

$LogDir = Join-Path $Root "launcher_logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$Log = Join-Path $LogDir ("runD_" + $stamp + ".log")
$Log | Out-File -FilePath (Join-Path $LogDir "LAST_LOG.txt") -Encoding UTF8

function LogLine([string]$s) {
  $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
  "$ts $s" | Out-File -FilePath $Log -Append -Encoding UTF8
  Write-Host $s
}

function Resolve-IdeaDir([string]$p) {
  if ([string]::IsNullOrWhiteSpace($p)) { return "" }
  if (-not (Test-Path $p)) {
    $cand = Join-Path $Root $p
    if (Test-Path $cand) { $p = $cand }
  }
  return (Resolve-Path $p).Path
}

try {
  LogLine "[DIAG] Root=$Root"
  LogLine "[DIAG] IdeaDir(arg)='$IdeaDir'"
  LogLine "[DIAG] All=$All"

  $py = Join-Path $Root ".venv\Scripts\python.exe"
  $script = Join-Path $Root "tools\d_gap_map.py"
  if (-not (Test-Path $py)) { throw "Python venv not found: $py (run 0_SETUP.bat)" }
  if (-not (Test-Path $script)) { throw "Not found: $script" }

  $failed = 0

  if ($All) {
    $ideas = Join-Path $Root "ideas"
    if (-not (Test-Path $ideas)) { throw "Folder 'ideas' not found." }
    $dirs = Get-ChildItem -Directory $ideas | Sort-Object LastWriteTime -Descending
    if (-not $dirs) { throw "No idea folders inside 'ideas'." }

    LogLine "[INFO] Processing ALL ideas: $($dirs.Count)"
    foreach ($d in $dirs) {
      $IdeaDir2 = $d.FullName
      LogLine "[INFO] ---- Idea: $IdeaDir2 ----"
      LogLine "[CMD] $py $script --idea `"$IdeaDir2`""
      $oldEAP = $ErrorActionPreference
      $ErrorActionPreference = "Continue"
      & $py $script --idea $IdeaDir2 2>&1 | Tee-Object -FilePath $Log -Append | Out-Host
      $ErrorActionPreference = $oldEAP
      $rc = $LASTEXITCODE
      LogLine "[DIAG] ExitCode=$rc"
      if ($rc -ne 0) { $failed++ }
    }

    if ($failed -gt 0) {
      LogLine "[WARN] Some ideas finished with non-zero exit code: $failed"
      exit 1
    } else {
      LogLine "[OK] Done. Gap maps generated for all ideas."
      exit 0
    }
  }

  if ([string]::IsNullOrWhiteSpace($IdeaDir)) {
    $ideas = Join-Path $Root "ideas"
    if (-not (Test-Path $ideas)) { throw "Folder 'ideas' not found. Run 1_NEW_IDEA.bat first." }
    $latest = Get-ChildItem -Directory $ideas | Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if (-not $latest) { throw "No idea folders inside 'ideas'. Run 1_NEW_IDEA.bat first." }
    $IdeaDir = $latest.FullName
    LogLine "[INFO] Using newest idea folder: $IdeaDir"
  } else {
    $IdeaDir = Resolve-IdeaDir $IdeaDir
    LogLine "[INFO] Using idea folder: $IdeaDir"
  }

  LogLine "[CMD] $py $script --idea `"$IdeaDir`""

  $oldEAP = $ErrorActionPreference
  $ErrorActionPreference = "Continue"
  & $py $script --idea $IdeaDir 2>&1 | Tee-Object -FilePath $Log -Append | Out-Host
  $ErrorActionPreference = $oldEAP

  $rc = $LASTEXITCODE
  LogLine "[DIAG] ExitCode=$rc"

  if ($rc -eq 0) {
    $out = Join-Path $IdeaDir "out\gap_map.md"
    if (Test-Path $out) {
      LogLine "[OK] gap_map.md created: $out"
    } else {
      LogLine "[WARN] gap_map.md not found (but script exit=0)."
    }
  }

  exit $rc
}
catch {
  LogLine "[ERROR] $($_.Exception.Message)"
  exit 1
}
