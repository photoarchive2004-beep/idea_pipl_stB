param(
  [ValidateSet("balanced","wide","focused")]
  [string]$Scope = "balanced",
  [string]$IdeaArg = "",
  [int]$N = 300
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
Set-Location $Root

$LogDir = Join-Path $Root "launcher_logs"
New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Log = Join-Path $LogDir "runB_last.log"
"" | Out-File -FilePath $Log -Encoding UTF8

function Log([string]$s){
  $s | Out-File -FilePath $Log -Append -Encoding UTF8
  Write-Host $s
}

function Resolve-IdeaDir([string]$arg) {
  $ideas = Join-Path $Root "ideas"
  if (-not (Test-Path $ideas)) { throw "Missing ideas folder. Run 1_NEW_IDEA.bat first." }

  if ([string]::IsNullOrWhiteSpace($arg)) {
    $active = Join-Path $ideas "_ACTIVE_PATH.txt"
    if (Test-Path $active) {
      $p = (Get-Content -LiteralPath $active -Raw).Trim()
      if ($p) {
        if (-not [IO.Path]::IsPathRooted($p)) { $p = Join-Path $Root $p }
        $p = [IO.Path]::GetFullPath($p)
        if (Test-Path $p) { return $p }
      }
    }
  }

  if ($arg -and $arg.Trim()) {
    $p = $arg
    if (-not [IO.Path]::IsPathRooted($p)) { $p = Join-Path $Root $p }
    $p = [IO.Path]::GetFullPath($p)
    if ((Split-Path -Leaf $p) -ieq "out") { $p = Split-Path -Parent $p }
    if (-not (Test-Path $p)) { throw "Idea folder not found: $p" }
    return $p
  }

  $cands = Get-ChildItem -LiteralPath $ideas -Directory -ErrorAction SilentlyContinue |
           Where-Object { $_.Name -like "IDEA-*" } |
           Sort-Object Name -Descending

  $withInputs = $cands | Where-Object {
    (Test-Path (Join-Path $_.FullName "out\structured_idea.json")) -or
    (Test-Path (Join-Path $_.FullName "idea.txt")) -or
    (Test-Path (Join-Path $_.FullName "in\idea.txt"))
  } | Select-Object -First 1
  if ($withInputs) { return $withInputs.FullName }

  $first = $cands | Select-Object -First 1
  if ($first) { return $first.FullName }

  throw "No IDEA-* folder found in ideas."
}

try {
  $IdeaDir = Resolve-IdeaDir $IdeaArg
  $IdeaDir = (Resolve-Path $IdeaDir).Path
  $outDir = Join-Path $IdeaDir "out"
  New-Item -ItemType Directory -Force -Path $outDir | Out-Null

  # invalidate old checkpoint when inputs updated
  $ckpt = Join-Path $outDir "_moduleB_checkpoint.json"
  $inp1 = Join-Path $outDir "structured_idea.json"
  $inp2 = Join-Path $IdeaDir "idea.txt"
  $inp3 = Join-Path $IdeaDir "in\idea.txt"
  if (Test-Path $ckpt) {
    $ck = (Get-Item $ckpt).LastWriteTimeUtc
    $newer = $false
    foreach ($p in @($inp1,$inp2,$inp3)) {
      if (Test-Path $p) {
        if ((Get-Item $p).LastWriteTimeUtc -gt $ck) { $newer = $true }
      }
    }
    if ($newer) {
      Remove-Item -Force -Path $ckpt -ErrorAction SilentlyContinue
      Log "[INFO] Input changed -> checkpoint removed"
    }
  }

  Log ("[INFO] ROOT=" + $Root)
  Log ("[INFO] IDEA_DIR=" + $IdeaDir)
  Log ("[INFO] SCOPE=" + $Scope)
  Log ("[INFO] N=" + $N)

  $script = Join-Path $Root "tools\b_lit_scout.py"
  if (-not (Test-Path $script)) { throw "Missing: $script" }

  $py = Join-Path $Root ".venv\Scripts\python.exe"
  if (-not (Test-Path $py)) { $py = "python" }

  Log ("[INFO] PY=" + $py)
  Log ("[INFO] CMD: " + $py + " " + $script + " --idea-dir " + $IdeaDir + " --n " + $N + " --scope " + $Scope)

  & $py $script --idea-dir $IdeaDir --n $N --scope $Scope
  exit $LASTEXITCODE
}
catch {
  Log ("[ERR] " + $_.Exception.Message)
  exit 1
}
